<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_babaijebu
 * 
 * @copyright   Copyright (c) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

//  No direct access to this file
defined('_JEXEC') or die('Restricted Access');

/**
 * General Controller of Babaijebu Component
 * 
 * @package Joomla.Administrator
 * @subpackage com_helloworld
 * @since 0.0.1
 */
class BabaijebuController extends JControllerLegacy
{
    /** @var sring $default_view The default view for the display method */
    protected $default_view = 'results';
}
