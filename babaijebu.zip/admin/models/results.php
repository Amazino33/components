<?php

/**
 * @package     Joomla.Administrator
 * @subpackage  com_helloworld
 * 
 * @copyright   Copyright (c) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

//  No direct access to this file
defined('_JEXEC') or die('Restricted Access');

/**
 * Results List Model
 * 
 * @since 0.0.1
 */
class BabaijebuModelResults extends JModelList
{
  /**
   * Constructor
   * 
   * @param    array    $config    An optional associative array of configuration settings.
   * 
   * @see      JController
   * @since    1.6
   */
  public function __construct($config = array())
  {
    if (empty($config['filter_fields'])) {
      $config['filter_fields'] = array(
        'id',
        'date',
        'name',
        'winning_num',
        'machine_num',
        'time',
        'published'
      );
    }

    parent::__construct($config);
  }

  /**
   * Method to build an SQL query to load the list data.
   *
   * @return string An SQL query
   **/
  protected function getListQuery()
  {
    // Initialize variables
    $db = JFactory::getDBO();
    $query = $db->getQuery(true);

    // Create the base select statement.
    $query->select(array('a.*', 'b.name','c.time'))
      ->from($db->quoteName('#__babaijebu_results', 'a'))
      ->join('INNER', $db->quoteName('#__babaijebu_name', 'b') . ' ON ' . $db->quoteName('a.name_id') . ' = ' . $db->quoteName('b.id'))
      ->join('INNER', $db->quoteName('#__babaijebu_time', 'c') . ' ON ' . $db->quoteName('a.time_id') . ' = ' . $db->quoteName('c.id'));

    // Filter: like / search
    $search = $this->getState('filter.search');

    if (!empty($search)) {
      $like = $db->quote('%' . $search . '%');
      $query->where('a.date LIKE ' . $like, ' OR ');
      $query->where('c.name LIKE ' . $like, ' OR ');
      $query->where('winning_num LIKE ' . $like, ' OR ');
      $query->where('machine_num LIKE ' . $like, ' OR ');
      $query->where('e.time LIKE ' . $like);
    }

    // Filter by published state
    $published = $this->getState('filter.published');

    if (is_numeric($published)) {
      if (!empty($search)) {
        $query->andWhere('published = ' . (int) $published);
      } else {
        $query->where('published = ' . (int) $published);
      }
    } elseif ($published === '') {
      if (!empty($search)) {
        $query->andWhere('(published IN (0, 1))');
      } else {
        $query->where('(published IN (0, 1))');
      }
    }

    // Add the list ordering clause.
    $orderCol = $this->state->get('list.ordering', 'a.id');
    $orderDirn = $this->state->get('list.direction', 'desc');

    $query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));

    return $query;
  }
}
