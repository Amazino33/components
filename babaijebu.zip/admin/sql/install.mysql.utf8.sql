SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS `#__babaijebu_results`;
CREATE TABLE `cm_babaijebu_results` (
	`id` INT(100) NOT NULL AUTO_INCREMENT,
	`date` VARCHAR(40) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`winning_num` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_unicode_ci',
	`machine_num` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_unicode_ci',
	`name_id` INT(100) NOT NULL,
	`time_id` INT(100) NOT NULL,
	`published` TINYINT(4) NOT NULL DEFAULT '1',
	PRIMARY KEY (`id`) USING BTREE,
	INDEX `daily_results` (`name_id`) USING BTREE,
	CONSTRAINT `result_name` FOREIGN KEY (`name_id`) REFERENCES `cm_babaijebu_name` (`id`) ON UPDATE NO ACTION ON DELETE NO ACTION,
	CONSTRAINT `result_time` FOREIGN KEY (`time_id`) REFERENCES `cm_babaijebu_time` (`id`) ON UPDATE NO ACTION ON DELETE NO ACTION
)
    ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;
 

 
DROP TABLE IF EXISTS `#__babaijebu_name`;
CREATE TABLE `#__babaijebu_name` (
    `id`        INT(11)     NOT NULL AUTO_INCREMENT,
    `name`   VARCHAR(25) NOT NULL,
    PRIMARY KEY (`id`)
)
    ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

    INSERT INTO `#__babaijebu_name` (`name`) VALUES
    ('PREMIER 06'),
    ('PREMIER BINGO'),
    ('PREMIER BONANZA'),
    ('PREMIER CLUB MASTER'),
    ('PREMIER DIAMOND'),
    ('PREMIER ENUGU'),
    ('PREMIER FAIRCHANCE'),
    ('PREMIER FORTUNE'),
    ('PREMIER GOLD'),
    ('PREMIER INTERNATIONAL'),
    ('PREMIER JACKPOT'),
    ('PREMIER KING'),
    ('PREMIER LUCKY'),
    ('PREMIER LUCKY G'),
    ('PREMIER METRO'),
    ('PREMIER MIDWEEK'),
    ('PREMIER MK II'),
    ('PREMIER MSP'),
    ('PREMIER NATIONAL'),
    ('PREMIER PEOPLES'),
    ('PREMIER ROYAL'),
    ('PREMIER SUPER'),
    ('PREMIER TOTA'),
    ('PREMIER VAG');


DROP TABLE IF EXISTS `#__babaijebu_time`;
CREATE TABLE `#__babaijebu_time` (
    `id`        INT(11)     NOT NULL AUTO_INCREMENT,
    `time`   VARCHAR(25) NOT NULL,
    PRIMARY KEY (`id`)
)
    ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;
    INSERT INTO `#__babaijebu_time` (`time`) VALUES
    ('9:45 AM'),
    ('12:45 PM'),
    ('3:45 PM'),
    ('7:45 PM'),
    ('10:45 PM');

DROP TABLE IF EXISTS `#__babaijebu_daily_results`;
CREATE TABLE `cm_babaijebu_daily_results` (
	`id` INT(50) NOT NULL AUTO_INCREMENT,
	`day_id` INT(50) NOT NULL,
	`name_id` INT(50) NOT NULL,
	`time_id` INT(50) NOT NULL,
	PRIMARY KEY (`id`) USING BTREE,
	INDEX `day_name` (`name_id`) USING BTREE,
	INDEX `day_time` (`time_id`) USING BTREE,
	INDEX `daily_day` (`day_id`) USING BTREE,
	CONSTRAINT `daily_day` FOREIGN KEY (`day_id`) REFERENCES `cm_babaijebu_day` (`id`) ON UPDATE NO ACTION ON DELETE NO ACTION,
	CONSTRAINT `daily_name` FOREIGN KEY (`name_id`) REFERENCES `cm_babaijebu_name` (`id`) ON UPDATE NO ACTION ON DELETE NO ACTION,
	CONSTRAINT `daily_time` FOREIGN KEY (`time_id`) REFERENCES `cm_babaijebu_time` (`id`) ON UPDATE NO ACTION ON DELETE NO ACTION
)
    ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;
    INSERT INTO `cm_babaijebu_daily_results` (`day_id`, `name_id`, `time_id`) VALUES 
    ('1', '5', '1'), ('1', '20', '2'), ('1', '2', '3'), ('1', '18', '4'), ('1', '15', '4'), ('1', '10', '5'),
    ('2', '9', '1'), ('2', '1', '2'), ('2', '11', '3'), ('2', '4', '4'), ('2', '15', '4'), ('2', '22', '5'),
    ('3', '23', '1'), ('3', '17', '2'), ('3', '6', '4'), ('3', '16', '4'), ('3', '13', '5'),
    ('4', '20', '1'), ('4', '7', '2'), ('4', '5', '3'), ('4', '10', '4'), ('4', '8', '4'), ('4', '2', '5'),
    ('5', '21', '1'), ('5', '15', '2'), ('5', '9', '3'), ('5', '11', '4'), ('5', '3', '4'), ('5', '24', '5'), 
    ('6', '12', '1'), ('6', '22', '2'), ('6', '4', '3'), ('6', '1', '4'), ('6', '19', '4'), ('6', '7', '5'),
    ('7', '21', '1'), ('7', '17', '2'), ('7', '6', '3'), ('7', '13', '4'), ('7', '23', '5');


DROP TABLE IF EXISTS `#__babaijebu_day`;
CREATE TABLE `cm_babaijebu_day` (
	`id` INT(50) NOT NULL AUTO_INCREMENT,
	`day` VARCHAR(50) NOT NULL COLLATE 'utf8_general_ci',
	PRIMARY KEY (`id`) USING BTREE
)
    ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;
    INSERT INTO `cm_babaijebu_day` (`day`) VALUES 
    ('Monday'),
    ('Tuesday'),
    ('Wednesday'),
    ('Thursday'),
    ('Friday'),
    ('Saturday'),
    ('Sunday');


SET FOREIGN_KEY_CHECKS=1;