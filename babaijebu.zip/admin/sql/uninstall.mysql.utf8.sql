SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS `#__babaijebu_result`;
DROP TABLE IF EXISTS `#__babaijebu_name`;
DROP TABLE IF EXISTS `#__babaijebu_time`;
DROP TABLE IF EXISTS `#__babaijebu_daily_results`;
DROP TABLE IF EXISTS `#__babaijebu_day`;

SET FOREIGN_KEY_CHECKS=1;