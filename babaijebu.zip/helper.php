<?php
/**
 * Hello World! Module Entry Point
 * 
 * @package     Joomla.Tutorials
 * @subpackage  Modules
 * @license     GNU/GPL, see LICENSE.php
 * @link        http://docs.joomla.org/J3.x:Creating_a_simple_module/Developing_a_Basic_Module
 * mod_helloworld is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
class ModHelloWorldHelper
{
    /**
     * Retrieves the hello message
     * 
     * @param   string   $params An object containing the module paramters
     * 
     * @access  public
     */
    public static function getHello($params, $wheres=array())
    {
        if ($params == '1' || $params == '2')
        {
            switch ($params) 
            {
                case '1':
                    $date = date("Y-m-d");
                    break;
    
                case '2':
                    $date = date("Y-m-d", strtotime("yesterday"));
                    break;
                
                default:
                    $date = date("Y-m-d");
                    break;
            }
        }
        // Obtain a database connection
        $db = JFactory::getDBO();

        // Retrieve the result
        $query = $db->getQuery(true)
            ->select(array('a.*', 'b.name', 'c.time'))
            ->from($db->quoteName('#__babaijebu_results', 'a'))
            ->join('INNER', $db->quoteName('#__babaijebu_name', 'b') . ' ON ' . $db->quoteName('a.name_id') . ' = ' . $db->quoteName('b.id'))
            ->join('INNER', $db->quoteName('#__babaijebu_time', 'c') . ' ON ' . $db->quoteName('a.time_id') . ' = ' . $db->quoteName('c.id'));
        
        if ($params == "1" || $params == "2")
        {
            $query->where($db->quoteName('a.date') . ' = ' . $db->Quote($date));
            if (!empty($wheres)) {
                foreach ($wheres as $key => $value) {
                    $query->where($db->quoteName($key).' = '.$db->Quote($value));
                }
            }
        }

        // Prepare the Query
        $db->setQuery($query);

        // Load the row.
        $result = $db->loadObjectList();

        // Return the Results
        return $result;
    }



    public static function getDayLotto($params)
    {
        switch ($params) 
        {
            case '1':
                $date = date("l");
                break;

            case '2':
                $date = date("l", strtotime("yesterday"));
                break;
            
            default:
                $date = date("l");
                break;
        }

        // Obtain a database connection
        $db = JFactory::getDBO();

        // Retrieve the result
        $query = $db->getQuery(true)
            ->select(array('a.*', 'b.name', 'c.time', 'd.day'))
            ->from($db->quoteName('#__babaijebu_daily_results', 'a'))
            ->join('INNER', $db->quoteName('#__babaijebu_name', 'b') . ' ON ' . $db->quoteName('a.name_id') . ' = ' . $db->quoteName('b.id'))
            ->join('INNER', $db->quoteName('#__babaijebu_time', 'c') . ' ON ' . $db->quoteName('a.time_id') . ' = ' . $db->quoteName('c.id'))
            ->join('INNER', $db->quoteName('#__babaijebu_day', 'd') . ' ON ' . $db->quoteName('a.day_id') . ' = ' . $db->quoteName('d.id'))
            ->where($db->quoteName('d.day') . ' = ' . $db->Quote($date));

        // Prepare the Query
        $db->setQuery($query);

        // Load the row.
        $result = $db->loadObjectList();

        // Return the Results
        return $result;

    }

    public static function getEachNum($numInput)
    {
        $removeNonNum = preg_replace('/[^0-9]/', ' ', $numInput);
        $removeNonNum = preg_replace('/ +/', ' ', $removeNonNum);
        $nums = explode(' ', $removeNonNum);

        return $nums;
    }
}
