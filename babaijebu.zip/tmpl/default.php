<style>
    .ltt-btn {
        background-color: green;
        color: #fff;
    }

    .ltt-container {
        display: flex;
        flex-direction: column;
        align-items: center;
        color: #333;
    }

    .ltt-divider {
        width: 40%;
        height: 1px;
        background-color: #ccc;
        margin: 30px 0px;
    }

    span.ltt-num {
        padding: 10px;
        border-radius: 50%;
        color: white;
        margin: 0 4px;
        font-weight: bold;
    }

    span.ltt-red {
        background-color: red;
    }

    span.ltt-green {
        background-color: green;
    }

    .ltt-btn {
        padding: 8px;
        border: none;
        border-radius: 4px;
    }

    .ltt-container h3,
    .ltt-container h4 {
        margin: 10px 0px;
    }

    .ltt-num-container {
        margin-bottom: 20px;
        text-align: center;
        display: flex;
        flex-direction: column;
        gap: 10px;
        align-items: center;
        justify-content: center;
    }
</style>


<div class="ltt-container">
    <?php if ($type == '1' || $type == '2') : ?>
        <h1>
            <?php
            if ($type == '1') {
                $date = date('l, jS \of F Y');
            } else if ($type == '2') {
                $date = date('l, jS \of F Y', strtotime('yesterday'));
            } else if ($type == '3') {
                $date = 'Table for All';
            }
            echo $date . ' Lotto Results';
            ?>
        </h1>
        <div>
            <button class="ltt-btn">Results Diamond Lotto</button>
            <button class="ltt-btn">Results Peoples Lotto</button>
            <button class="ltt-btn">Results Bingo Lotto</button>
            <button class="ltt-btn">Results MSP Lotto</button>
            <button class="ltt-btn">Results Metro Lotto</button>
            <button class="ltt-btn">Results International Lotto</button>
        </div>
        <div class="ltt-divider"></div>
        <?php
        $total_results =  count($daily);

        if ($type == '1' || $type == '2') {
            foreach ($daily as $i => $row) {
                $arr = array(
                    'name' => $row->name,
                    'time' => $row->time
                );
                $nums = ModHelloWorldHelper::getHello($type, $arr);
        ?>
                <h2><?= $row->name ?> LOTTO RESULTS</h2>
                <h4><?= $date ?> | <small><?= $row->time ?></small></h4>
                <div class="ltt-num-container">
                    Lotto Winning Number
                    <div>
                        <?php
                        if (empty($nums)) {
                            $wNum = ['?', '?', '?', '?', '?'];
                        ?>
                            <span class="ltt-green ltt-num"><?= $wNum[0] ?></span>
                            <span class="ltt-green ltt-num"><?= $wNum[1] ?></span>
                            <span class="ltt-red ltt-num"><?= $wNum[2] ?></span>
                            <span class="ltt-green ltt-num"><?= $wNum[3] ?></span>
                            <span class="ltt-green ltt-num"><?= $wNum[4] ?></span>
                    </div>
                    <?php
                        } else {
                            foreach ($nums as $j => $num) {
                                $wNum = ModHelloWorldHelper::getEachNum($num->winning_num);
                    ?>
                        <span class="ltt-green ltt-num"><?= $wNum[0] ?></span>
                        <span class="ltt-green ltt-num"><?= $wNum[1] ?></span>
                        <span class="ltt-red ltt-num"><?= $wNum[2] ?></span>
                        <span class="ltt-green ltt-num"><?= $wNum[3] ?></span>
                        <span class="ltt-green ltt-num"><?= $wNum[4] ?></span>
                </div>
        <?php
                            }
                        }
        ?>
</div>

<div class="ltt-num-container">
    Lotto Machine Number
    <div>
        <?php
                if (empty($nums)) {
                    $mNum = ['?', '?', '?', '?', '?'];
        ?>
            <span class="ltt-green ltt-num"><?= $mNum[0] ?></span>
            <span class="ltt-green ltt-num"><?= $mNum[1] ?></span>
            <span class="ltt-red ltt-num"><?= $mNum[2] ?></span>
            <span class="ltt-green ltt-num"><?= $mNum[3] ?></span>
            <span class="ltt-green ltt-num"><?= $mNum[4] ?></span>
    </div>
    <?php
                } else {
                    foreach ($nums as $j => $num) {
                        $mNum = ModHelloWorldHelper::getEachNum($num->winning_num);
    ?>
        <span class="ltt-green ltt-num"><?= $mNum[0] ?></span>
        <span class="ltt-green ltt-num"><?= $mNum[1] ?></span>
        <span class="ltt-red ltt-num"><?= $mNum[2] ?></span>
        <span class="ltt-green ltt-num"><?= $mNum[3] ?></span>
        <span class="ltt-green ltt-num"><?= $mNum[4] ?></span>
</div>
<?php
                    }
                }
?>
</div>

<button class="ltt-btn"><?= $row->name ?> RESULTS</button>
<div class="ltt-divider"></div>
<?php
            }
        }
    endif;
?>





</div>